#include <iostream>

using namespace std;

int main()
{
    int arr[] = {6,9,6,4,3};
    int n = sizeof(arr)/sizeof(arr[0]);
    for(int i=0; i<n; i++)
        arr[i] = arr[i]*2;
    for(int i=0; i<n; i++)
        cout<<arr[i]<<" ";
    cout<<"Hello World";

    return 0;
}